		<div class="topbar">
			<i class="bx bx-menu toggle-menu"></i>

			<div class="search">
				<input type="search" placeholder="Search here....">
				<button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
			</div>

			<a href="#" class="notification">
				<i class='bx bxs-bell'></i>
			</a>

			<div class="user">
				<img src="https://via.placeholder.com/36" alt="User">
				<div>
					<h4>Anjan Saha</h4>
					<small>Super Admin</small>
				</div>
			</div>
		</div>